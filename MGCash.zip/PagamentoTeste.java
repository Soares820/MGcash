public class PagamentoTeste {
    public static void main(String[] args) {
        Empregado[] lista = new Empregado[6];

        lista[0] = new EmpregadoHorista("Lucas", 0, 160, 20);
        lista[1] = new EmpregadoHorista("Joana", 0, 140, 18);
        lista[2] = new EmpregadoComissionado("Paulo", 1000, 5000, 0.10);
        lista[3] = new EmpregadoComissionado("Marina", 1200, 8000, 0.12);
        lista[4] = new EmpregadoAssalariado("Ricardo", 2500);
        lista[5] = new EmpregadoAssalariado("Clara", 2800);

        System.out.println("=== Detalhes dos Funcionários ===");
        for (Empregado emp : lista) {
            emp.exibirDetalhes();
            System.out.println("-----------------------");
        }

        double total = 0;

        System.out.println("=== Relatório Final ===");
        for (Empregado emp : lista) {
            String tipo;
            if (emp instanceof EmpregadoHorista) {
                tipo = "Horista";
            } else if (emp instanceof EmpregadoComissionado) {
                tipo = "Comissionado";
            } else {
                tipo = "Assalariado";
            }
            System.out.println("Nome: " + emp.nome + " | Tipo: " + tipo + " | Salário: R$ " + emp.calcularSalario());
            total += emp.calcularSalario();
        }

        System.out.println("Total geral a pagar: R$ " + total);
    }
}