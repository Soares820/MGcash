abstract class Empregado {
    String nome;
    double salarioBase;

    Empregado(String nome, double salarioBase) {
        this.nome = nome;
        this.salarioBase = salarioBase;
    }

    abstract double calcularSalario();

    void exibirDetalhes() {
        System.out.println("Nome: " + nome);
        System.out.println("Salário: R$ " + calcularSalario());
    }
}