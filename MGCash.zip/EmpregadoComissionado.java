class EmpregadoComissionado extends Empregado {
    double vendas;
    double percentualComissao;

    EmpregadoComissionado(String nome, double salarioBase, double vendas, double percentualComissao) {
        super(nome, salarioBase);
        this.vendas = vendas;
        this.percentualComissao = percentualComissao;
    }

    @Override
    double calcularSalario() {
        return salarioBase + (vendas * percentualComissao);
    }

    @Override
    void exibirDetalhes() {
        System.out.println("Nome: " + nome);
        System.out.println("Salário: R$ " + calcularSalario());
    }
}