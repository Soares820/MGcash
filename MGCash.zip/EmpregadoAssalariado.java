class EmpregadoAssalariado extends Empregado {
    EmpregadoAssalariado(String nome, double salarioBase) {
        super(nome, salarioBase);
    }

    @Override
    double calcularSalario() {
        return salarioBase;
    }

    @Override
    void exibirDetalhes() {
        System.out.println("Nome: " + nome);
        System.out.println("Salário: R$ " + calcularSalario());
    }
}