class EmpregadoHorista extends Empregado {
    int horasTrabalhadas;
    double valorHora;

    EmpregadoHorista(String nome, double salarioBase, int horasTrabalhadas, double valorHora) {
        super(nome, salarioBase);
        this.horasTrabalhadas = horasTrabalhadas;
        this.valorHora = valorHora;
    }

    @Override
    double calcularSalario() {
        return horasTrabalhadas * valorHora;
    }

    @Override
    void exibirDetalhes() {
        System.out.println("Nome: " + nome);
        System.out.println("Salário: R$ " + calcularSalario());
    }
}